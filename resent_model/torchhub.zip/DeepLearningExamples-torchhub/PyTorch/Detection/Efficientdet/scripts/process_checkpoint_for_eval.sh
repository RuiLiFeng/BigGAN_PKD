#!/bin/bash

python utils/checkpoint_processing.py --checkpoint_path /checkpoints/model_best.pth.tar --state_dict_path /checkpoints/Effdet_B0.pth