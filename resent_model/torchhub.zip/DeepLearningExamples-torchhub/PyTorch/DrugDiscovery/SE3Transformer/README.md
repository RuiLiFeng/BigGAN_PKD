# [SE(3)-Transformers For PyTorch [migrated, click here]](https://github.com/NVIDIA/DeepLearningExamples/blob/master/DGLPyTorch/DrugDiscovery/SE3Transformer)

![Model high-level architecture](../../../DGLPyTorch/DrugDiscovery/SE3Transformer/images/se3-transformer.png)

