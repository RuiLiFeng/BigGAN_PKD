#!/bin/bash

# install ffmpeg
# apt-get update
# apt-get install -y ffmpeg

# install the project and its dependencies
pip install --user --no-cache-dir .