# FasterTransformer

## This repo can now be found here: https://github.com/NVIDIA/FasterTransformer.
